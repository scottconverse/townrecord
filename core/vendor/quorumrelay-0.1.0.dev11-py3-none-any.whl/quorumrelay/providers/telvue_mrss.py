"""Public compatibility facade; implementation objects retain their identity."""

from civic_data_connectors.providers.telvue_mrss import *  # noqa: F401,F403
