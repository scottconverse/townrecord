"""Canonical namespace facade for the FilePro SOAP binding."""
from civic_data_connectors.providers.civicweb_soap import *  # noqa: F403
