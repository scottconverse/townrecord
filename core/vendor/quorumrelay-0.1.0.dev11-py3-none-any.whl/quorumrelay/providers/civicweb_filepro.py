"""Canonical namespace facade for FilePro document records."""
from civic_data_connectors.providers.civicweb_filepro import *  # noqa: F403
